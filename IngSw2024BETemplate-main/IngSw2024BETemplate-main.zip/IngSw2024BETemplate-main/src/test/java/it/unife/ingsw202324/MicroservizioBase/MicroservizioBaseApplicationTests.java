package it.unife.ingsw202324.MicroservizioBase;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroservizioBaseApplicationTests {

	@Test
	void contextLoads() {
	}

}
